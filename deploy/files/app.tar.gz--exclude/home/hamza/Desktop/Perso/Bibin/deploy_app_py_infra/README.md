# pyinfra-python-app-deploy
This project aims to show how you can deploy production ready a python app using the wonderful library pyinfra
